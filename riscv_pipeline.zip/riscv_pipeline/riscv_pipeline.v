// 5-stage pipelined RISC-V (RV32I subset) processor
// Stages: IF -> ID -> EX -> MEM -> WB
// Supports: add sub and or xor slt sll srl sra (R-type)
//           addi andi ori xori slti slli srli srai (I-type)
//           lw sw, beq bne blt bge, jal
// Hazards : forwarding (EX/MEM and MEM/WB -> EX), load-use stall (1 cycle),
//           branch/jump resolved in EX (2 instructions flushed when taken)
module riscv_pipeline(
    input clk,
    input rst
);
    localparam NOP = 32'h00000013;

    // =====================================================================
    // Wires that are used across stages
    // =====================================================================
    wire        stall;
    wire        branch_taken;
    wire [31:0] branch_target;
    wire [31:0] wb_data;

    // =====================================================================
    // IF stage
    // =====================================================================
    reg  [31:0] pc;
    wire [31:0] instr_f;
    wire [31:0] pc_next = branch_taken ? branch_target : (pc + 32'd4);

    always @(posedge clk) begin
        if (rst)         pc <= 32'd0;
        else if (!stall) pc <= pc_next;
    end

    instr_mem u_imem(.addr(pc), .instr(instr_f));

    // ---------------- IF/ID pipeline register ----------------
    reg [31:0] if_id_pc, if_id_instr;
    always @(posedge clk) begin
        if (rst || branch_taken) begin
            if_id_pc    <= 32'd0;
            if_id_instr <= NOP;
        end else if (!stall) begin
            if_id_pc    <= pc;
            if_id_instr <= instr_f;
        end
    end

    // =====================================================================
    // ID stage
    // =====================================================================
    wire [6:0] opcode   = if_id_instr[6:0];
    wire [4:0] rd_id    = if_id_instr[11:7];
    wire [2:0] funct3   = if_id_instr[14:12];
    wire [4:0] rs1_id   = if_id_instr[19:15];
    wire [4:0] rs2_id   = if_id_instr[24:20];
    wire       funct7_5 = if_id_instr[30];

    wire c_reg_write, c_alu_src, c_mem_read, c_mem_write, c_mem_to_reg, c_branch, c_jump;
    wire [1:0] c_alu_op;
    control_unit u_ctrl(
        .opcode(opcode), .reg_write(c_reg_write), .alu_src(c_alu_src),
        .mem_read(c_mem_read), .mem_write(c_mem_write), .mem_to_reg(c_mem_to_reg),
        .branch(c_branch), .jump(c_jump), .alu_op(c_alu_op)
    );

    wire [31:0] imm_id;
    imm_gen u_imm(.instr(if_id_instr), .imm(imm_id));

    wire [31:0] rs1_val_id, rs2_val_id;
    reg         mem_wb_reg_write;
    reg  [4:0]  mem_wb_rd;
    regfile u_rf(
        .clk(clk), .we(mem_wb_reg_write), .waddr(mem_wb_rd), .wdata(wb_data),
        .raddr1(rs1_id), .raddr2(rs2_id), .rdata1(rs1_val_id), .rdata2(rs2_val_id)
    );

    reg        id_ex_mem_read;
    reg [4:0]  id_ex_rd;
    hazard_unit u_haz(
        .id_ex_mem_read(id_ex_mem_read), .id_ex_rd(id_ex_rd),
        .if_id_rs1(rs1_id), .if_id_rs2(rs2_id), .stall(stall)
    );

    // ---------------- ID/EX pipeline register ----------------
    reg [31:0] id_ex_pc, id_ex_rs1_val, id_ex_rs2_val, id_ex_imm;
    reg [4:0]  id_ex_rs1, id_ex_rs2;
    reg [2:0]  id_ex_funct3;
    reg        id_ex_funct7_5;
    reg        id_ex_reg_write, id_ex_mem_to_reg, id_ex_mem_write;
    reg        id_ex_alu_src, id_ex_branch, id_ex_jump;
    reg [1:0]  id_ex_alu_op;

    always @(posedge clk) begin
        if (rst || branch_taken || stall) begin
            // bubble: all zero = does nothing
            id_ex_pc <= 0; id_ex_rs1_val <= 0; id_ex_rs2_val <= 0; id_ex_imm <= 0;
            id_ex_rs1 <= 0; id_ex_rs2 <= 0; id_ex_rd <= 0;
            id_ex_funct3 <= 0; id_ex_funct7_5 <= 0;
            id_ex_reg_write <= 0; id_ex_mem_to_reg <= 0; id_ex_mem_read <= 0;
            id_ex_mem_write <= 0; id_ex_alu_src <= 0; id_ex_branch <= 0;
            id_ex_jump <= 0; id_ex_alu_op <= 0;
        end else begin
            id_ex_pc        <= if_id_pc;
            id_ex_rs1_val   <= rs1_val_id;
            id_ex_rs2_val   <= rs2_val_id;
            id_ex_imm       <= imm_id;
            id_ex_rs1       <= rs1_id;
            id_ex_rs2       <= rs2_id;
            id_ex_rd        <= rd_id;
            id_ex_funct3    <= funct3;
            id_ex_funct7_5  <= funct7_5;
            id_ex_reg_write <= c_reg_write;
            id_ex_mem_to_reg<= c_mem_to_reg;
            id_ex_mem_read  <= c_mem_read;
            id_ex_mem_write <= c_mem_write;
            id_ex_alu_src   <= c_alu_src;
            id_ex_branch    <= c_branch;
            id_ex_jump      <= c_jump;
            id_ex_alu_op    <= c_alu_op;
        end
    end

    // =====================================================================
    // EX stage
    // =====================================================================
    reg  [31:0] ex_mem_alu_result;
    reg  [4:0]  ex_mem_rd;
    reg         ex_mem_reg_write;

    wire [1:0] fwd_a, fwd_b;
    forwarding_unit u_fwd(
        .id_ex_rs1(id_ex_rs1), .id_ex_rs2(id_ex_rs2),
        .ex_mem_rd(ex_mem_rd), .ex_mem_reg_write(ex_mem_reg_write),
        .mem_wb_rd(mem_wb_rd), .mem_wb_reg_write(mem_wb_reg_write),
        .fwd_a(fwd_a), .fwd_b(fwd_b)
    );

    reg [31:0] op_a, op_b;   // operands after forwarding
    always @(*) begin
        case (fwd_a)
            2'b10:   op_a = ex_mem_alu_result;
            2'b01:   op_a = wb_data;
            default: op_a = id_ex_rs1_val;
        endcase
        case (fwd_b)
            2'b10:   op_b = ex_mem_alu_result;
            2'b01:   op_b = wb_data;
            default: op_b = id_ex_rs2_val;
        endcase
    end

    wire [31:0] alu_in_b = id_ex_alu_src ? id_ex_imm : op_b;
    wire [3:0]  alu_ctrl;
    wire [31:0] alu_result;

    alu_control u_aluctl(
        .alu_op(id_ex_alu_op), .funct3(id_ex_funct3),
        .funct7_5(id_ex_funct7_5), .alu_ctrl(alu_ctrl)
    );
    alu u_alu(.a(op_a), .b(alu_in_b), .alu_ctrl(alu_ctrl), .result(alu_result));

    // jal writes PC+4 into rd
    wire [31:0] ex_result = id_ex_jump ? (id_ex_pc + 32'd4) : alu_result;

    // branch decision (done in EX stage)
    wire eq = (op_a == op_b);
    wire lt = ($signed(op_a) < $signed(op_b));
    reg  take_cond;
    always @(*) begin
        case (id_ex_funct3)
            3'b000:  take_cond = eq;    // beq
            3'b001:  take_cond = ~eq;   // bne
            3'b100:  take_cond = lt;    // blt
            3'b101:  take_cond = ~lt;   // bge
            default: take_cond = 1'b0;
        endcase
    end
    assign branch_taken  = (id_ex_branch & take_cond) | id_ex_jump;
    assign branch_target = id_ex_pc + id_ex_imm;

    // ---------------- EX/MEM pipeline register ----------------
    reg [31:0] ex_mem_store_data;
    reg        ex_mem_mem_to_reg, ex_mem_mem_read, ex_mem_mem_write;
    always @(posedge clk) begin
        if (rst) begin
            ex_mem_alu_result <= 0; ex_mem_store_data <= 0; ex_mem_rd <= 0;
            ex_mem_reg_write <= 0; ex_mem_mem_to_reg <= 0;
            ex_mem_mem_read <= 0; ex_mem_mem_write <= 0;
        end else begin
            ex_mem_alu_result <= ex_result;
            ex_mem_store_data <= op_b;          // forwarded value is stored by sw
            ex_mem_rd         <= id_ex_rd;
            ex_mem_reg_write  <= id_ex_reg_write;
            ex_mem_mem_to_reg <= id_ex_mem_to_reg;
            ex_mem_mem_read   <= id_ex_mem_read;
            ex_mem_mem_write  <= id_ex_mem_write;
        end
    end

    // =====================================================================
    // MEM stage
    // =====================================================================
    wire [31:0] mem_read_data;
    data_mem u_dmem(
        .clk(clk), .mem_read(ex_mem_mem_read), .mem_write(ex_mem_mem_write),
        .addr(ex_mem_alu_result), .write_data(ex_mem_store_data),
        .read_data(mem_read_data)
    );

    // ---------------- MEM/WB pipeline register ----------------
    reg [31:0] mem_wb_read_data, mem_wb_alu_result;
    reg        mem_wb_mem_to_reg;
    always @(posedge clk) begin
        if (rst) begin
            mem_wb_read_data <= 0; mem_wb_alu_result <= 0; mem_wb_rd <= 0;
            mem_wb_reg_write <= 0; mem_wb_mem_to_reg <= 0;
        end else begin
            mem_wb_read_data  <= mem_read_data;
            mem_wb_alu_result <= ex_mem_alu_result;
            mem_wb_rd         <= ex_mem_rd;
            mem_wb_reg_write  <= ex_mem_reg_write;
            mem_wb_mem_to_reg <= ex_mem_mem_to_reg;
        end
    end

    // =====================================================================
    // WB stage
    // =====================================================================
    assign wb_data = mem_wb_mem_to_reg ? mem_wb_read_data : mem_wb_alu_result;
endmodule
