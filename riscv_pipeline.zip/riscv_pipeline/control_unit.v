// Main control unit: opcode -> control signals
module control_unit(
    input  [6:0] opcode,
    output reg   reg_write,
    output reg   alu_src,     // 1 = use immediate as ALU input B
    output reg   mem_read,
    output reg   mem_write,
    output reg   mem_to_reg,  // 1 = write-back data comes from memory
    output reg   branch,
    output reg   jump,
    output reg [1:0] alu_op
);
    always @(*) begin
        reg_write = 0; alu_src = 0; mem_read = 0; mem_write = 0;
        mem_to_reg = 0; branch = 0; jump = 0; alu_op = 2'b00;
        case (opcode)
            7'b0110011: begin reg_write = 1; alu_op = 2'b10; end                           // R-type
            7'b0010011: begin reg_write = 1; alu_src = 1; alu_op = 2'b11; end              // I-type ALU
            7'b0000011: begin reg_write = 1; alu_src = 1; mem_read = 1; mem_to_reg = 1; end // lw
            7'b0100011: begin alu_src = 1; mem_write = 1; end                              // sw
            7'b1100011: begin branch = 1; end                                              // beq/bne/blt/bge
            7'b1101111: begin reg_write = 1; jump = 1; end                                 // jal
            default: ;                                                                      // treated as NOP
        endcase
    end
endmodule
