// Data memory (word addressed, lw/sw only)
module data_mem(
    input         clk,
    input         mem_read,
    input         mem_write,
    input  [31:0] addr,
    input  [31:0] write_data,
    output [31:0] read_data
);
    reg [31:0] mem [0:63];
    integer k;
    initial for (k = 0; k < 64; k = k + 1) mem[k] = 32'd0;

    always @(posedge clk)
        if (mem_write) mem[addr[7:2]] <= write_data;

    assign read_data = mem_read ? mem[addr[7:2]] : 32'd0;
endmodule
