// Instruction memory (ROM). Program is written directly in the initial block
// so no file path problems in Vivado. Replace the words to run your own program.
module instr_mem(
    input  [31:0] addr,
    output [31:0] instr
);
    reg [31:0] mem [0:63];
    integer k;
    initial begin
        for (k = 0; k < 64; k = k + 1) mem[k] = 32'h00000013;   // NOP (addi x0,x0,0)
        mem[0]  = 32'h00500093;  // addi x1, x0, 5
        mem[1]  = 32'h00a00113;  // addi x2, x0, 10
        mem[2]  = 32'h002081b3;  // add  x3, x1, x2     (forwarding)
        mem[3]  = 32'h40110233;  // sub  x4, x2, x1
        mem[4]  = 32'h00302023;  // sw   x3, 0(x0)
        mem[5]  = 32'h00002283;  // lw   x5, 0(x0)
        mem[6]  = 32'h00128333;  // add  x6, x5, x1     (load-use stall)
        mem[7]  = 32'h00120463;  // beq  x4, x1, +8     (taken, flush)
        mem[8]  = 32'h06300393;  // addi x7, x0, 99     (must be skipped)
        mem[9]  = 32'h00100413;  // addi x8, x0, 1
        mem[10] = 32'h0000006f;  // jal  x0, 0          (loop here forever)
    end
    assign instr = mem[addr[7:2]];
endmodule
