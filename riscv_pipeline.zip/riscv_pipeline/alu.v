// ALU control: decides which operation the ALU does
module alu_control(
    input  [1:0] alu_op,      // 00 = add, 10 = R-type, 11 = I-type
    input  [2:0] funct3,
    input        funct7_5,    // instr[30]
    output reg [3:0] alu_ctrl
);
    localparam ADD = 4'b0000, SUB = 4'b0001, AND_ = 4'b0010, OR_ = 4'b0011,
               XOR_ = 4'b0100, SLT = 4'b0101, SLL = 4'b0110, SRL = 4'b0111,
               SRA = 4'b1000;

    always @(*) begin
        case (alu_op)
            2'b00: alu_ctrl = ADD;                       // lw, sw, jal
            2'b10, 2'b11: begin                          // R-type, I-type
                case (funct3)
                    3'b000: alu_ctrl = (alu_op == 2'b10 && funct7_5) ? SUB : ADD;
                    3'b001: alu_ctrl = SLL;
                    3'b010: alu_ctrl = SLT;
                    3'b100: alu_ctrl = XOR_;
                    3'b101: alu_ctrl = funct7_5 ? SRA : SRL;
                    3'b110: alu_ctrl = OR_;
                    3'b111: alu_ctrl = AND_;
                    default: alu_ctrl = ADD;
                endcase
            end
            default: alu_ctrl = ADD;
        endcase
    end
endmodule

module alu(
    input  [31:0] a,
    input  [31:0] b,
    input  [3:0]  alu_ctrl,
    output reg [31:0] result
);
    always @(*) begin
        case (alu_ctrl)
            4'b0000: result = a + b;
            4'b0001: result = a - b;
            4'b0010: result = a & b;
            4'b0011: result = a | b;
            4'b0100: result = a ^ b;
            4'b0101: result = ($signed(a) < $signed(b)) ? 32'd1 : 32'd0;
            4'b0110: result = a << b[4:0];
            4'b0111: result = a >> b[4:0];
            4'b1000: result = $signed(a) >>> b[4:0];
            default: result = 32'd0;
        endcase
    end
endmodule
