`timescale 1ns / 1ps
module tb_riscv_pipeline;
    reg clk = 0;
    reg rst = 1;

    riscv_pipeline dut(.clk(clk), .rst(rst));

    always #5 clk = ~clk;               // 10 ns clock

    initial begin
        #22 rst = 0;                    // release reset after 2 clock edges
        #400;                           // let the program finish

        $display("---------------- Final register values ----------------");
        $display("x1 = %0d (expect 5)",  dut.u_rf.regs[1]);
        $display("x2 = %0d (expect 10)", dut.u_rf.regs[2]);
        $display("x3 = %0d (expect 15)", dut.u_rf.regs[3]);
        $display("x4 = %0d (expect 5)",  dut.u_rf.regs[4]);
        $display("x5 = %0d (expect 15)", dut.u_rf.regs[5]);
        $display("x6 = %0d (expect 20)", dut.u_rf.regs[6]);
        $display("x7 = %0d (expect 0, instruction was flushed)", dut.u_rf.regs[7]);
        $display("x8 = %0d (expect 1)",  dut.u_rf.regs[8]);
        $display("mem[0] = %0d (expect 15)", dut.u_dmem.mem[0]);

        if (dut.u_rf.regs[1] == 5  && dut.u_rf.regs[2] == 10 &&
            dut.u_rf.regs[3] == 15 && dut.u_rf.regs[4] == 5  &&
            dut.u_rf.regs[5] == 15 && dut.u_rf.regs[6] == 20 &&
            dut.u_rf.regs[7] == 0  && dut.u_rf.regs[8] == 1  &&
            dut.u_dmem.mem[0] == 15)
            $display("RESULT: PASS");
        else
            $display("RESULT: FAIL");
        $finish;
    end
endmodule
